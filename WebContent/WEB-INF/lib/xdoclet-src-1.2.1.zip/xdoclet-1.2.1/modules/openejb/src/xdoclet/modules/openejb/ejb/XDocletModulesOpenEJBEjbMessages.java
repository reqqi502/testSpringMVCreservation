/*
 * Copyright (c) 2001, 2002 The XDoclet team
 * All rights reserved.
 */
package xdoclet.modules.openejb.ejb;

/**
 * @created   January 24, 2004
 */
public class XDocletModulesOpenEJBEjbMessages
{
}
