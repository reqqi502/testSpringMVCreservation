/*
 * Copyright (c) 2001, 2002 The XDoclet team
 * All rights reserved.
 */
package xdoclet.modules.openejb.ejb;

import xdoclet.tagshandler.ClassTagsHandler;

/**
 * @author               Brian Topping (topping@orb.org)
 * @created              January 23, 2004
 * @xdoclet.taghandler   namespace="OpenEJB"
 * @version              $Revision: 1.1 $
 */
public class OpenEJBTagsHandler extends ClassTagsHandler
{

}
