/*
 * Copyright (c) 2001, 2002 The XDoclet team
 * All rights reserved.
 */
package xdoclet.modules.hibernate;

import xdoclet.DocletTask;

/**
 * @author        S�bastien Guimont (sebastieng@sympatico.ca)
 * @created       August 9th, 2002
 * @version       $Revision: 1.1 $
 * @ant.element   name="hibernatedoclet" display-name="Hibernate Task"
 */
public class HibernateDocletTask extends DocletTask
{
}
