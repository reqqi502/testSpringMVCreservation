/*
 * Copyright (c) 2001, 2002 The XDoclet team
 * All rights reserved.
 */
package xdoclet.modules.jmx;

import xdoclet.DocletTask;

/**
 * @author        Rickard Oberg (rickard@xpedio.com)
 * @created       August 4, 2001
 * @ant.element   name="jmxdoclet" display-name="JMX Task"
 * @version       $Revision: 1.3 $
 */
public class JMXDocletTask extends DocletTask
{
}

