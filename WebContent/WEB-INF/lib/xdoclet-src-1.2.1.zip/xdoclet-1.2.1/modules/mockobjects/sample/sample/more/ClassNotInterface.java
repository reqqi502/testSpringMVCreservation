package sample.more;

public class ClassNotInterface {

	public ClassNotInterface() {
		super();
	}

	public void newMethod() {
	}

}