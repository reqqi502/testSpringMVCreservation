package sample.more;

/**
 * @mock:generate
 */
public interface OverloadedMethod {

	String overloadedMethod(int anInt);

	String overloadedMethod(int anInt, String aString);
}