package sample.more;

/**
 * @mock:generate
 */
public interface InterfaceWithNoMethods {
}