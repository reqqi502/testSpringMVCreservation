package sample.more;

/**
 * @mock:generate
 */
public interface OneVoidMethod {
	void newMethod();
}