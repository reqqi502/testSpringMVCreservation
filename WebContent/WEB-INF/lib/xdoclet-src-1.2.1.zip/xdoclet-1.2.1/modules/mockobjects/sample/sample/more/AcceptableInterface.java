package sample.more;

/**
 * @mock:generate
 */
public interface AcceptableInterface {
	int[] difficultMethod(String aString, OneVoidMethod[] aFunnyObject);
	void minimalMethod();
	String normalMethod(Integer anInteger);
}