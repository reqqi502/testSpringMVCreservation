package sample.more;

/**
 * @mock:generate
 */
public interface NonObjectParameterMethods {

	void newMethod(byte notAnObject);

	void newMethod(char notAnObject);

	void newMethod(double notAnObject);

	void newMethod(float notAnObject);

	void newMethod(int notAnObject);

	void newMethod(long notAnObject);

	void newMethod(short notAnObject);

	void newMethod(boolean notAnObject);
}