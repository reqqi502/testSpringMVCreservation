package sample.more;

/**
 * @mock:generate
 */
public interface OneIntReturningMethod {

	int toInt();
}