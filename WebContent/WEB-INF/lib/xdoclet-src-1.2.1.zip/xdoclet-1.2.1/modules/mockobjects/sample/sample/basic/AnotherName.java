package sample.basic;

/**
 * This class will have a mock generated that doesn't follow the usual
 * naming conventions.
 *
 * @mock:generate class="MagicalMockThing"
 */
public interface AnotherName {

	String eatThings( Object food );

}
