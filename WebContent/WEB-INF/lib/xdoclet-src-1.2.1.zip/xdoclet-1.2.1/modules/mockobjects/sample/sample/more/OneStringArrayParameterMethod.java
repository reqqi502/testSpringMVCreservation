package sample.more;

/**
 * @mock:generate
 */
public interface OneStringArrayParameterMethod {

	void newMethod(String[][] strings);
}