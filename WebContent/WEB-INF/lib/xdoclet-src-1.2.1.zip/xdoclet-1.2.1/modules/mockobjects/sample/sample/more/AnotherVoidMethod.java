package sample.more;

/**
 * @mock:generate
 */
public interface AnotherVoidMethod extends OneVoidMethod {
	void childMethod();
}