package sample.more;

/**
 * @mock:generate
 */
public interface OneStringReturningMethod {
	String toString();
}