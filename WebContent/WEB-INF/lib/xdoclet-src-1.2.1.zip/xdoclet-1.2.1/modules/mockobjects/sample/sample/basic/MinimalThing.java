package sample.basic;

/**
 * Here is my MinimalThing.
 *
 * @mock:generate
 */
public interface MinimalThing {

	/**
	 * Do nothing special.
	 */
	void minimalMethod();

}
