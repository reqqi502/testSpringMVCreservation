package sample.more;

/**
 * @mock:generate
 */
public interface ExceptionThrowingMethod {
	void newMethod() throws SomeCheckedException;
}