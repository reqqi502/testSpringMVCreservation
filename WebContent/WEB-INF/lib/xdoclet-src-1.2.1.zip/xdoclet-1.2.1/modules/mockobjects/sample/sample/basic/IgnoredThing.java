package sample.basic;

/**
 * I don't want a mock generated.
 */
public interface IgnoredThing {

	/**
	 * Nothing special.
	 */
	void doSomething();

}
