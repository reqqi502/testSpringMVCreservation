package sample.basic;

/**
 * This class will have a mock generated in a different package.
 *
 * @mock:generate class="sample.someplace.MockThing"
 */
public interface AnotherPackage {

	String eatThings( Object food );

}
