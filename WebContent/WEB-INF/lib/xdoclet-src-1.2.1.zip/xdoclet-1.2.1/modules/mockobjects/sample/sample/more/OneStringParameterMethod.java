package sample.more;

/**
 * @mock:generate
 */
public interface OneStringParameterMethod {
	void newMethod(String aString);
}