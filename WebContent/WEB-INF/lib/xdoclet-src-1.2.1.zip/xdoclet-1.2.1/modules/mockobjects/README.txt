The generated mocks depend on
com.mockobjects.*
and
xdoclet.modules.mockobjects.util.ReturnObjectList (included in this module)