Optional (non-standardised) modules go here. The package naming should follow the following scheme:

xdoclet.modules.vendorname.productname.[subproductname]

For the sake of simplicity and consistensy, related sub-tasks and tag-handlers should be in the same package.

The XDoclet Team