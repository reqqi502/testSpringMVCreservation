/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;
import javax.ejb.CreateException;

/**
 * Local interface for simple/CreateMethodSL.
 * @xdoclet-generated at 02-mars-02 12:49:33
 */
public interface CreateMethodSLLocal
   extends xdoclet.retest.bean.ejb.interfaces.SimpleSLLocal
{

}
