/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Home interface for simple/IFTagSL. Lookup using {1}
 * @xdoclet-generated at 02-mars-02 13:12:13
 */
public interface IFTagSLHome
   extends xdoclet.retest.bean.ejb.base.BaseEJBHome, javax.ejb.EJBHome
{
   public static final String COMP_NAME="java:comp/env/ejb/simple/IFTagSL";
   public static final String JNDI_NAME="simple/IFTagSL";

   public IFTagSL create() throws javax.ejb.CreateException, java.rmi.RemoteException;

}
