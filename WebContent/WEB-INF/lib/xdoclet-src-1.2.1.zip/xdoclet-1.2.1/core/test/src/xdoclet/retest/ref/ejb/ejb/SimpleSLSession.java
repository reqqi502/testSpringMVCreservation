/*
* $Id: SimpleSLSession.java,v 1.2 2002/06/12 21:27:53 ara_e_w Exp $
*/
package xdoclet.retest.ref.ejb.ejb;

public class SimpleSLSession
        extends xdoclet.retest.bean.ejb.ejb.SimpleSLBean
        implements javax.ejb.SessionBean
{
    public void ejbActivate()
    {
    }

    public void ejbPassivate()
    {
    }

    public void setSessionContext(javax.ejb.SessionContext ctx)
    {
    }

    public void unsetSessionContext()
    {
    }

    public void ejbRemove()
    {
    }

    public void ejbCreate()
    {
    }

}
