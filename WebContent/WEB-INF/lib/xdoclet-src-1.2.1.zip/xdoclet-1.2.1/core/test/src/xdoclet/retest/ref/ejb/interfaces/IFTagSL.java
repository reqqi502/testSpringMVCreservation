/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Remote interface for simple/IFTagSL.
 * @xdoclet-generated at 02-mars-02 13:12:14
 */
public interface IFTagSL
   extends xdoclet.retest.bean.ejb.base.BaseEJBObject, javax.ejb.EJBObject
{

}
