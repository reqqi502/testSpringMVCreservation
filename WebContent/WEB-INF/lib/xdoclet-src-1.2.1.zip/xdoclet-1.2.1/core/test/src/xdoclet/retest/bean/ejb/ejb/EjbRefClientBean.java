/*
 * $Id: EjbRefClientBean.java,v 1.1 2002/03/10 18:06:00 vharcq Exp $
 */
package xdoclet.retest.bean.ejb.ejb;

import javax.ejb.EntityBean;

/**
 * @ejb:bean
 *      name="ejbref/EjbRefClient"
 *      type="CMP"
 *      view-type="both"
 *      cmp-version="2.x"
 *
 */
public abstract class EjbRefClientBean
        implements EntityBean
{
}
