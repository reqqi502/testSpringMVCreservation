/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;
import javax.ejb.CreateException;

/**
 * Home interface for simple/CreateMethodSL. Lookup using {1}
 * @xdoclet-generated at 02-mars-02 12:49:33
 */
public interface CreateMethodSLHome
   extends xdoclet.retest.bean.ejb.interfaces.SimpleSLHome
{
   public static final String COMP_NAME="java:comp/env/ejb/simple/CreateMethodSL";
   public static final String JNDI_NAME="simple/CreateMethodSL";

   public CreateMethodSL createBlaBla() throws CreateException, java.rmi.RemoteException;

}
