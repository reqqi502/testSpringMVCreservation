/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;
import javax.ejb.CreateException;

/**
 * Local home interface for simple/CreateMethodSL. Lookup using {1}
 * @xdoclet-generated at 02-mars-02 12:49:33
 */
public interface CreateMethodSLLocalHome
   extends xdoclet.retest.bean.ejb.interfaces.SimpleSLLocalHome
{
   public static final String COMP_NAME="java:comp/env/ejb/simple/CreateMethodSLLocal";
   public static final String JNDI_NAME="simple/CreateMethodSLLocal";

   public CreateMethodSLLocal createBlaBla() throws CreateException;

}
