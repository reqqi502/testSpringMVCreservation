/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Remote interface for simple/SimpleSL.
 * @xdoclet-generated at 23-f�vr.-02 16:19:08
 */
public interface SimpleSL
   extends javax.ejb.EJBObject
{
    public void doSomething(  ) throws java.rmi.RemoteException;

    public void doSomething( int a ) throws java.rmi.RemoteException;

    public void doSomething( int[] a ) throws java.rmi.RemoteException;

    public void doSomething( java.lang.String a ) throws java.rmi.RemoteException;

    public void doSomething( java.lang.String[] a ) throws java.rmi.RemoteException;

    public int[] iadoSomething(  ) throws java.rmi.RemoteException;

    public int[] iadoSomething( int a ) throws java.rmi.RemoteException;

    public int[] iadoSomething( int[] a ) throws java.rmi.RemoteException;

    public int[] iadoSomething( java.lang.String a ) throws java.rmi.RemoteException;

    public int[] iadoSomething( java.lang.String[] a ) throws java.rmi.RemoteException;

    public int idoSomething(  ) throws java.rmi.RemoteException;

    public int idoSomething( int a ) throws java.rmi.RemoteException;

    public int idoSomething( int[] a ) throws java.rmi.RemoteException;

    public int idoSomething( java.lang.String a ) throws java.rmi.RemoteException;

    public int idoSomething( java.lang.String[] a ) throws java.rmi.RemoteException;

    public java.lang.String[] sadoSomething(  ) throws java.rmi.RemoteException;

    public java.lang.String[] sadoSomething( int[] a ) throws java.rmi.RemoteException;

    public java.lang.String[] sadoSomething( java.lang.String a ) throws java.rmi.RemoteException;

    public java.lang.String[] sadoSomething( java.lang.String[] a ) throws java.rmi.RemoteException;

    public java.lang.String sdoSomething(  ) throws java.rmi.RemoteException;

    public java.lang.String sdoSomething( int a ) throws java.rmi.RemoteException;

    public java.lang.String sdoSomething( int[] a ) throws java.rmi.RemoteException;

    public java.lang.String sdoSomething( java.lang.String a ) throws java.rmi.RemoteException;

    public java.lang.String sdoSomething( java.lang.String[] a ) throws java.rmi.RemoteException;

    public java.lang.String[] siadoSomething( int a ) throws java.rmi.RemoteException;

 }
