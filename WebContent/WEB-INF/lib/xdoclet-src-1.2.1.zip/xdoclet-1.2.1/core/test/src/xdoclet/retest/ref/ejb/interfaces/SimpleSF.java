/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Remote interface for simple/SimpleSF.
 * @xdoclet-generated at 25-f�vr.-02 8:04:41
 */
public interface SimpleSF
   extends javax.ejb.EJBObject
{

   public void doSomething(  ) throws java.rmi.RemoteException;

   public void doSomething( int a ) throws java.rmi.RemoteException;

   public void doSomething( int[] a ) throws java.rmi.RemoteException;

   public void doSomething( String a ) throws java.rmi.RemoteException;

   public void doSomething( String[] a ) throws java.rmi.RemoteException;

   public int[] iadoSomething(  ) throws java.rmi.RemoteException;

   public int[] iadoSomething( int a ) throws java.rmi.RemoteException;

   public int[] iadoSomething( int[] a ) throws java.rmi.RemoteException;

   public int[] iadoSomething( String a ) throws java.rmi.RemoteException;

   public int[] iadoSomething( String[] a ) throws java.rmi.RemoteException;

   public int idoSomething(  ) throws java.rmi.RemoteException;

   public int idoSomething( int a ) throws java.rmi.RemoteException;

   public int idoSomething( int[] a ) throws java.rmi.RemoteException;

   public int idoSomething( String a ) throws java.rmi.RemoteException;

   public int idoSomething( String[] a ) throws java.rmi.RemoteException;

   public String[] sadoSomething(  ) throws java.rmi.RemoteException;

   public String[] sadoSomething( int[] a ) throws java.rmi.RemoteException;

   public String[] sadoSomething( String a ) throws java.rmi.RemoteException;

   public String[] sadoSomething( String[] a ) throws java.rmi.RemoteException;

   public String sdoSomething(  ) throws java.rmi.RemoteException;

   public String sdoSomething( int a ) throws java.rmi.RemoteException;

   public String sdoSomething( int[] a ) throws java.rmi.RemoteException;

   public String sdoSomething( String a ) throws java.rmi.RemoteException;

   public String sdoSomething( String[] a ) throws java.rmi.RemoteException;

   public String[] siadoSomething( int a ) throws java.rmi.RemoteException;

}
