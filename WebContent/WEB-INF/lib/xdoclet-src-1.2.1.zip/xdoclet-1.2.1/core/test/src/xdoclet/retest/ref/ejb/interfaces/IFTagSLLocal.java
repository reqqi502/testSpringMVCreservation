/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Local interface for simple/IFTagSL.
 * @xdoclet-generated at 02-mars-02 13:12:14
 */
public interface IFTagSLLocal
   extends xdoclet.retest.bean.ejb.base.BaseEJBLocalObject, javax.ejb.EJBLocalObject
{

}
