/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.EntityBean;

/**
 * Local interface for inherited/cmp/InheritedCMPSub.
 * @xdoclet-generated at 14-mars-02 20:35:08
 */
public interface InheritedCMPSubLocal
   extends javax.ejb.EJBLocalObject
{

}
