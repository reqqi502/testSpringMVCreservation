/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.ejb;

import java.lang.*;
import javax.ejb.SessionBean;
import javax.ejb.CreateException;

/**
 * Session layer for simple/SimpleSF.
 * @xdoclet-generated at 25-f�vr.-02 8:04:41
 */
public class SimpleSFSession
   extends xdoclet.retest.bean.ejb.ejb.SimpleSFBean
   implements SessionBean
{
   public void ejbActivate()
   {
   }

   public void ejbPassivate()
   {
   }

   public void setSessionContext(javax.ejb.SessionContext ctx)
   {
   }

   public void unsetSessionContext()
   {
   }

   public void ejbRemove()
   {
   }

   public void ejbCreate() throws CreateException
   {
      super.ejbCreate();
   }

}
