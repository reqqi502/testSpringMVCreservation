/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.ejb;

import java.lang.*;
import javax.ejb.SessionBean;
import javax.ejb.CreateException;

/**
 * Session layer for simple/CreateMethodSL.
 * @xdoclet-generated at 02-mars-02 12:55:01
 */
public class CreateMethodSLSession
   extends xdoclet.retest.bean.ejb.ejb.CreateMethodSLBean
   implements SessionBean
{
   public void ejbActivate()
   {
   }

   public void ejbPassivate()
   {
   }

   public void setSessionContext(javax.ejb.SessionContext ctx)
   {
   }

   public void unsetSessionContext()
   {
   }

   public void ejbRemove()
   {
   }

   public void ejbCreate()
   {
   }

}
