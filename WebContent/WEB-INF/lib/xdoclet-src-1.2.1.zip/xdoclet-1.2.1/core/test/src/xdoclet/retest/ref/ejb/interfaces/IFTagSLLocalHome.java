/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Local home interface for simple/IFTagSL. Lookup using {1}
 * @xdoclet-generated at 02-mars-02 13:12:13
 */
public interface IFTagSLLocalHome
   extends xdoclet.retest.bean.ejb.base.BaseEJBLocalHome, javax.ejb.EJBLocalHome
{
   public static final String COMP_NAME="java:comp/env/ejb/simple/IFTagSLLocal";
   public static final String JNDI_NAME="simple/IFTagSLLocal";

   public IFTagSLLocal create() throws javax.ejb.CreateException;

}
