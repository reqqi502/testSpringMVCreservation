package xdoclet.retest.test;

/**
 * @author    Vincent Harcq (vincent.harcq@hubmethods.com)
 * @created   Mars 5, 2002
 * @version   $Revision: 1.4 $
 */
public class EntityBeanRegressionTestCase
extends EnterpriseJavaBeanRegressionTestCase
{

    public EntityBeanRegressionTestCase(String name)
    {
        super(name);
    }

    public EntityBeanRegressionTestCase(String name,String cn)
    {
        super(name,cn);
    }


}
