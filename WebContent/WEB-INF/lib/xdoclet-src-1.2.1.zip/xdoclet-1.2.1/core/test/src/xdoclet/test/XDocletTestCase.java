package xdoclet.test;

import junit.framework.TestCase;

/**
 * @author    Vincent Harcq (vincent.harcq@hubmethods.com)
 * @created   March 11, 2002
 * @version   $Revision: 1.1 $
 */
public abstract class XDocletTestCase
        extends TestCase
{
    public XDocletTestCase(String name){
        super(name);
    }

}
