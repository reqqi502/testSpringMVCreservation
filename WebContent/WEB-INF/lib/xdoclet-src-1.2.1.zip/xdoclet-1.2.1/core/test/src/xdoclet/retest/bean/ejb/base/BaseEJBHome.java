/*
 * $Id: BaseEJBHome.java,v 1.1 2002/03/02 12:16:44 vharcq Exp $
 */
package xdoclet.retest.bean.ejb.base;

public interface BaseEJBHome
{
}
