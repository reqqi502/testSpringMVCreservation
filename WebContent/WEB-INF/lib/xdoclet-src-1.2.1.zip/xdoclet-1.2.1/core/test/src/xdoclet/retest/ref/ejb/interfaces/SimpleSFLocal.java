/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Local interface for simple/SimpleSF.
 * @xdoclet-generated at 25-f�vr.-02 8:04:41
 */
public interface SimpleSFLocal
   extends javax.ejb.EJBLocalObject
{

   public void doSomething(  ) ;

   public void doSomething( int a ) ;

   public void doSomething( int[] a ) ;

   public void doSomething( String a ) ;

   public void doSomething( String[] a ) ;

   public int[] iadoSomething(  ) ;

   public int[] iadoSomething( int a ) ;

   public int[] iadoSomething( int[] a ) ;

   public int[] iadoSomething( String a ) ;

   public int[] iadoSomething( String[] a ) ;

   public int idoSomething(  ) ;

   public int idoSomething( int a ) ;

   public int idoSomething( int[] a ) ;

   public int idoSomething( String a ) ;

   public int idoSomething( String[] a ) ;

   public String[] sadoSomething(  ) ;

   public String[] sadoSomething( int[] a ) ;

   public String[] sadoSomething( String a ) ;

   public String[] sadoSomething( String[] a ) ;

   public String sdoSomething(  ) ;

   public String sdoSomething( int a ) ;

   public String sdoSomething( int[] a ) ;

   public String sdoSomething( String a ) ;

   public String sdoSomething( String[] a ) ;

   public String[] siadoSomething( int a ) ;

}
