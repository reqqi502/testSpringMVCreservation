/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Home interface for simple/SimpleSL.
 * @xdoclet-generated at 23-f�vr.-02 16:19:08
 */
public interface SimpleSLHome
   extends javax.ejb.EJBHome
{
   public static final String COMP_NAME="java:comp/env/ejb/simple/SimpleSL";
   public static final String JNDI_NAME="simple/SimpleSL";

   public xdoclet.retest.ref.ejb.interfaces.SimpleSL create() throws javax.ejb.CreateException, java.rmi.RemoteException;

}
