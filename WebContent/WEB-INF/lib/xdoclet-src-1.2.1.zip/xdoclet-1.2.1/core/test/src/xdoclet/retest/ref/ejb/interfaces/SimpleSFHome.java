/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Home interface for simple/SimpleSF.
 * @xdoclet-generated at 25-f�vr.-02 8:04:40
 */
public interface SimpleSFHome
   extends javax.ejb.EJBHome
{
   public static final String COMP_NAME="java:comp/env/ejb/simple/SimpleSF";
   public static final String JNDI_NAME="simple/SimpleSF";

   public SimpleSF create() throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF create(int a) throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF create(int[] a) throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF create(String a) throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF create(String[] a) throws javax.ejb.CreateException,java.lang.IllegalAccessException,java.lang.IllegalArgumentException,java.rmi.RemoteException;

   public SimpleSF createBlaBla() throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF createBlaBla(int a) throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF createBlaBla(int[] a) throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF createBlaBla(String a) throws javax.ejb.CreateException,java.rmi.RemoteException;

   public SimpleSF createBlaBla(String[] a) throws javax.ejb.CreateException,java.rmi.RemoteException;

}
