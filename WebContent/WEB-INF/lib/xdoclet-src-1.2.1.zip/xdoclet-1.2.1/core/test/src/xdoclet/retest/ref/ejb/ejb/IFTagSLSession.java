/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.ejb;

import java.lang.*;
import javax.ejb.SessionBean;

/**
 * Session layer for simple/IFTagSL.
 * @xdoclet-generated at 02-mars-02 13:12:14
 */
public class IFTagSLSession
   extends xdoclet.retest.bean.ejb.ejb.IFTagSLBean
   implements SessionBean
{
   public void ejbActivate()
   {
   }

   public void ejbPassivate()
   {
   }

   public void setSessionContext(javax.ejb.SessionContext ctx)
   {
   }

   public void unsetSessionContext()
   {
   }

   public void ejbRemove()
   {
   }

   public void ejbCreate()
   {
   }

}
