/*
 * Generated file - Do not edit!
 */
package xdoclet.retest.ref.ejb.interfaces;

import java.lang.*;
import javax.ejb.EntityBean;

/**
 * Local interface for simple/SimpleCMP.
 * @xdoclet-generated at 05-mars-02 22:51:01
 */
public interface SimpleCMPLocal
   extends javax.ejb.EJBLocalObject
{
   /**
    * Abstract cmp2 field get-set pair for field aByte
    * Get the value of aByte
    * @return value of aByte
    */
   public byte getAByte(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field aChar
    * Get the value of aChar
    * @return value of aChar
    */
   public char getAChar(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field aDouble
    * Get the value of aDouble
    * @return value of aDouble
    */
   public double getADouble(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field aFloat
    * Get the value of aFloat
    * @return value of aFloat
    */
   public float getAFloat(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field aLong
    * Get the value of aLong
    * @return value of aLong
    */
   public long getALong(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field aShort
    * Get the value of aShort
    * @return value of aShort
    */
   public short getAShort(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field anInt
    * Get the value of anInt
    * @return value of anInt
    */
   public int getAnInt(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field anObject
    * Get the value of anObject
    * @return value of anObject
    */
   public Object getAnObject(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field anObjectArray
    * Get the value of anObjectArray
    * @return value of anObjectArray
    */
   public Object[] getAnObjectArray(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field id
    * Get the value of id
    * @return value of id
    */
   public Integer getId(  ) ;

   /**
    * Abstract cmp2 field get-set pair for field aBoolean
    * Get the value of aBoolean
    * @return value of aBoolean
    */
   public boolean isABoolean(  ) ;

}
